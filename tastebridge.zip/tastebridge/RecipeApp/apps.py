from django.apps import AppConfig


class RecipeappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'RecipeApp' # set application name
